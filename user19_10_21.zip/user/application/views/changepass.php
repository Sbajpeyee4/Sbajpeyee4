<!DOCTYPE html>
<html lang="en">
 <head>
    <title>777HUB</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="<?=base_url()?>assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?=base_url()?>assets/css/style.css" rel="stylesheet">
    <link href="<?=base_url()?>assets/css/aos.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  </head>
  <body>
  <main id="main">
   <div class="container">
    <section>
    <div class="row justify-content-center">
      <div class="col-sm-4">
      <div class="change-card">
      <form>
        <i class="fa fa-lock fa-6x"></i>
        <h4 class="fnt-30">Change Password?</h4>
        <span class="fnt-14">You can change your password here.</span>
        <div class="form-group">
        <label>Enter Current Password</label>
        <input type="password" name="" class="form-control" required="">
        </div>
        <div class="descrip">
          <p>आपके अकाउंट की सुरक्षा को ध्यान रखते हुए आपके लिए कंप्यूटर जनित पासवर्ड बनाया जा रहा है | नीचे दिए गए बटन पर क्लिक करके एक नया पासवर्ड बनाएं|</p>
          <p>Keeping in mind the security of your account, a computer-generated password is being created for you.. Create a new password by clicking on the button below</p>
        </div>
          <button type="submit" class="btn btn-primary w-100">Generate Password</button>
        </form>
      </div>
      </div>
     </div>
  </section>
    </main>
  </body>

</html>