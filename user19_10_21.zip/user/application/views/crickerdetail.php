<!DOCTYPE html>
<html lang="en">
 <head>
    <title>777HUB</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="<?=base_url()?>assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?=base_url()?>assets/css/style.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  </head>

<body class="bg-light">
  <!-- ======= Header ======= -->
  <header>
  <nav class="navbar navbar-expand-lg navbar-light">
  <div class="container-fluid">
    <div class="navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="navbar-brand" href="index"><img src="<?=base_url()?>assets/images/logo.png"></a>
        </li>
        <li class="nav-item text-center cointext">
         <h5>TESTING </h5>
         		<input type="text" id="serverUrl" value="ws://148.251.21.118:5570"/>
         		<textarea id="sendMessage">{"RequestType":1,"data":{"Firm":"PUNJAB","PrivateKey":"INDOR@0","ApiKey":"CRIC@20"}}</textarea>
         <h5><span>Coins : <span id='coins'><?=$user_data[0]->current_limit?></span></span></h5>
         <h6><span>Used Coin : <span>0</span></span></h6>
         <h6><span>Session P/M : <span>0</span></span></h6>
        </li>
        <li class="nav-item nav-links">
        <a href="login">
        <span>
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-box-arrow-in-right" viewBox="0 0 16 16">
        <path fill-rule="evenodd" d="M6 3.5a.5.5 0 0 1 .5-.5h8a.5.5 0 0 1 .5.5v9a.5.5 0 0 1-.5.5h-8a.5.5 0 0 1-.5-.5v-2a.5.5 0 0 0-1 0v2A1.5 1.5 0 0 0 6.5 14h8a1.5 1.5 0 0 0 1.5-1.5v-9A1.5 1.5 0 0 0 14.5 2h-8A1.5 1.5 0 0 0 5 3.5v2a.5.5 0 0 0 1 0v-2z"/>
        <path fill-rule="evenodd" d="M11.854 8.354a.5.5 0 0 0 0-.708l-3-3a.5.5 0 1 0-.708.708L10.293 7.5H1.5a.5.5 0 0 0 0 1h8.793l-2.147 2.146a.5.5 0 0 0 .708.708l3-3z"/>
      </svg>
      </span>
       <h5>Logout</h5>
          </a>
        </li>
      </ul>
  
    </div>
  </div>
</nav>
  </header>
  <!-- End Header -->
  <body>
 <button id="shoTv" class="backbtn text-uppercase font-weight-bold"><img src="<?=base_url()?>assets/images/tv.png"><span>Show Tv</span></button>
 <div class="toggleDiv">
  <video width="100%" height="300" autoplay controls="">
  <source src="" type="video/mp4">
  <source src="" type="video/ogg">
</video>
 </div>
  <main class="p-0">
   <div class="container-fluid">
    <section>
    <div class="row">
    <div class="col-sm-12 p-0">
    <div class="table-responsive">
     <table class="table tablerun mt-2 mb-0">
       <tbody>
         <tr>
           <td class="w-35">
            <div>
            <h5>( )*</h5>
            <h5>( )*</h5>
            <h5>BOWLER :</h5>
            </div>
            </td>
           <td class="w-35">
            <div>
            <h5>AAAA (NAN)</h5>
            <h5>BBBB (NAN)</h5>
            <h5>6 BALLS :</h5>
            </div>
          </td>
           <td class="w-35">
             <div><img src="<?=base_url()?>assets/images/blank.jpg" style="width:43px;"></div>
           </td>
         </tr>
       </tbody>
     </table>
   </div>
    </div>
    <div class="col-sm-12 mt-2 p-0 tableteam">
    <div class="table-responsive">
     <table class="table text-center">
       <tbody>
        <tbody>
          <tr>
            <td class="thheader">
              TEAM<br>Max : 200K
            </td>
            <td class="thheader">
            KHAI
            </td>
            <td class="thheader">
              
                LAGAI
            </td>
          </tr>
          <tr>
              <input  type='hidden' id='bet_type' >
            <td><span><?=$match_data[0]->first_team_id ?> :</span><span class="text-blue">0</span></td>
            <td onclick="firstkhaiFunction()"><input  type='hidden' id='first_khai_input' value='1.4' ><span class="text-blue betting"  id='first_khai'  >1.4</span></td>
            <td onclick="firstlgaiFunction()"> <input  type='hidden'  id='first_lgai_input' value='2.4' ><span class="text-red betting" id='first_lgai'   >2.4</span></td>
          </tr>
            <tr>
            <td><span><?=$match_data[0]->second_team_id ?> :</span><span class="text-blue">0</span></td>
            <td onclick="secondkhaiFunction()"> <input type='hidden' id='second_khai_input' value='0' ><span class="text-blue betting " id='second_khai'>0.00</span></td>
            <td onclick="secondlgaiFunction()"> <input  type='hidden' id='second_lgai_input' value='0' > <span class="text-red betting" id='second_lgai' >0.00</span></td>
          </tr>
          
           
        </tbody>
       </tbody>
     </table>
     
     <table class="table text-center">
       <tbody>
        <tbody id ='session_table'>
             <tr>
            <td class="thheader">
              SESSION
            </td>
            <td class="thheader">
              NOT
            </td>
            <td class="thheader">
              YES
            </td>
          </tr>
          <!--<tr>-->
          <!--  <td class="subtitle"><h6>6 OVER RUN AAAA</h6>-->
          <!--    <span>Session Limit : 1K</span></td>-->
          <!--  <td><span class="text-blue">00</span></td>-->
          <!--  <td><span class="text-red">0</span></td>-->
          <!--</tr>-->
            </tbody>
       </tbody>
     </table>
   </div>
    </div>
    <div class="col-sm-12 mt-2 p-0 bluetable">
    <div class="table-responsive">
     <table class="table text-center" border="0"> 
       <tbody>
         <tr>
           <td >AMOUNT</td>
           <td><input type="text" name="" readonly="" id='amount' ></td>
           <td><input type="text" name="" class="amount" id='progressBar' readonly=""></td>
           <td  onclick="myFunction()" >Done</td>
         </tr>
       </tbody>
     </table>
    </div>
   </div>
     <div class="col-sm-12 mt-2 p-0 lasttable">
      <div class="table-responsive">
      <table class="table">
        <tbody>
          <tr>
            <td class="text-center">Sr.</td>
            <td class="text-right">Rate</td>
            <td class="text-right">Amount</td>
            <td class="text-center">Mode</td>
            <td class="text-right">Team</td>
          </tr>
          <?php $i=1; foreach($bat_data as $bat){ ?>
          <tr>
            <td ><?=$i?></td>
            <td ><?=$bat->rate?></td>
            <td ><?=$bat->amount?></td>
            <td ><?=$bat->bet_type?></td>
            <td ><?=$bat->fav_team?></td>
          </tr>
          <?php $i++; } ?>
        </tbody>
      </table>
     </div>
    </div>
     <div class="col-sm-12 mt-2 p-0 lasttable">
      <div class="table-responsive">
      <table class="table">
        <tbody>
          <tr>
            <td class="text-center">Sr.</td>
            <td class="text-right">Session</td>
            <td class="text-right">Rate</td>
            <td class="text-center">Amount</td>
            <td class="text-right">Run</td>
            <td class="text-right">Run</td>
            <td class="text-right">Mode</td>
            <td class="text-right">Dec</td>
          </tr>
          
        </tbody>
      </table>
     </div>
    </div>
  </div>
    </section>   
      </div>
   </main><!-- End #main -->
<a href="index" class="backbtn" onclick="goBack()" >BACK TO MAIN MENU</a>
  <!-- ======= Footer ======= -->
  <footer>
  <div class="footer">
    Copy Right @ 777HUB
  </div>
  </footer>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>

function secondkhaiFunction() {
  $("#bet_type").val('second_khai'); 
}
 
function secondlgaiFunction() {
  $("#bet_type").val('second_lgai'); 
}

function firstkhaiFunction() {
  $("#bet_type").val('first_khai'); 
}

function firstlgaiFunction() {
  $("#bet_type").val('first_lgai'); 
}
function myFunction() {
var bet_type =  $("#bet_type").val(); 
var match_id =  '<?=$match_data[0]->match_code  ?>'; 
   if(bet_type=='first_khai'){
        var rate =  $("#first_khai_input").val(); 
        var mode ='khai';
        var fav_team = '<?=$match_data[0]->first_team_id ?>';
   }else if(bet_type=='first_lgai'){
        var mode ='lagai';
        var rate =  $("#first_lgai_input").val();
        var fav_team = '<?=$match_data[0]->first_team_id ?>';
   }else if(bet_type=='second_khai'){
        var mode ='khai';
        var rate =  $("#second_khai_input").val(); 
        var fav_team = '<?=$match_data[0]->second_team_id ?>';
   }else if(bet_type=='second_lgai'){
        var mode ='lagai';
        var rate =  $("#second_lgai_input").val(); 
        var fav_team = '<?=$match_data[0]->second_team_id ?>';
   }
   var amount =  $("#amount").val(); 
   var coins =  $("#coins").html(); 
    coins =    parseInt(coins);
  
   var first_team =  '<?=$match_data[0]->first_team_id ?>'; 
   var second_team =  '<?=$match_data[0]->second_team_id ?>'; 
   
   if(coins>=amount){
     
  $.ajax({    
            type: 'post',
            url: "<?php echo base_url('home/add_bat');?>",
            data:{match_id:match_id,bet_type:bet_type,second_team:second_team,first_team:first_team,amount:amount,fav_team:fav_team,rate:rate,mode:mode},
            
            success: function (result) {
                console.log(result);
            //   var res =  $.parseJSON(result);
            // alert('Category added succefully');
          location.reload();
            }
      });
   }else{
       alert('insufficient coins');
   }
      
   
}







$(document).ready(function(){
  $("#shoTv").click(function(){
     $('#shoTv span').text($(this).text() == 'Hide TV' ? 'Show Tv' : 'Hide TV');
    $(".toggleDiv").slideToggle(); 
  });
   $(".alert").click(function(){
    alert('Not Find any run or rate ');
  });
  $(".betting").click(function(){
      $("#amount").removeAttr("readonly");
     var timeleft = 1;
var downloadTimer = setInterval(function(){
  if(timeleft <= 1){
    clearInterval(downloadTimer);
  }
  document.getElementById("progressBar").value = 10 - timeleft;
  timeleft += 1;
}, 1000);

    alert('Not Find any run or rate ');
  });
  
  
  
  
});
</script>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.3/jquery.min.js"></script>
<!--<script type="text/javascript" src="<?=base_url()?>assets/index.js"></script>-->
<script >
    new function() {
	var ws = null;
	var connected = false;

	var serverUrl;
	var connectionStatus;
	var sendMessage;
	
	var connectButton;
	var disconnectButton; 
	var sendButton;

	var open = function() {
		var url = serverUrl.val();
		ws = new WebSocket(url);
		ws.onopen = onOpen;
		ws.onclose = onClose;
		ws.onmessage = onMessage;
		ws.onerror = onError;

		connectionStatus.text('OPENING ...');
		serverUrl.attr('disabled', 'disabled');
		connectButton.hide();
		disconnectButton.show();
	}
	
	var close = function() {
		if (ws) {
			console.log('CLOSING ...');
// 			ws.close();
		}
		connected = false;
		connectionStatus.text('CLOSED');

		serverUrl.removeAttr('disabled');
		connectButton.show();
		disconnectButton.hide();
// 		sendMessage.attr('disabled', 'disabled');
		sendButton.attr('disabled', 'disabled');
	}
	
	var clearLog = function() {
// 		$('#messages').html('');
	}
	
	var onOpen = function() {
		console.log('OPENED: ' + serverUrl.val());
		connected = true;
		connectionStatus.text('OPENED');
// 		sendMessage.removeAttr('disabled');
		sendButton.removeAttr('disabled');
	};
	
	var onClose = function() {
		console.log('CLOSED: ' + serverUrl.val());
		ws = null;
	};
	
	var onMessage = function(event) {
		var data = event.data;
		addMessage(data);
	};
	
	var onError = function(event) {
		alert(event.data);
	}
	
	var addMessage = function(data, type) {
	    var match_id = '<?=$match_data[0]->match_code  ?>'
	    var first_id = '<?=$match_data[0]->first_team_id  ?>'
	    var second_id = '<?=$match_data[0]->second_team_id  ?>'
	    console.log(match_id);
	    console.log(data);
	    const obj = JSON.parse(data);
	    console.log(obj);
	    if(obj.data.MatchId == match_id ){
	        console.log(obj.data);
        	   if(obj.responseType=='10'){
            	   if(first_id==obj.data.RateType){
            	       console.log(obj.data.BackLays[3].Price); 
            	       console.log('pass'); 
            	          $('#second_khai').html('0.00');
            	       $('#first_khai').html(obj.data.BackLays[3].Price);
            	       $('#first_khai_input').val(obj.data.BackLays[3].Price);
            	       $('#first_lgai').html(obj.data.BackLays[0].Price);
            	       $('#first_lgai_input').val(obj.data.BackLays[0].Price);
            	   }else{
            	       console.log(obj.data.BackLays[0].Price); 
            	           console.log('fail'); 
            	           $('#first_khai').html('0.00');
            	             $('#second_khai').html(obj.data.BackLays[3].Price);
            	       $('#second_khai_input').val(obj.data.BackLays[3].Price);
            	       $('#second_lgai').html(obj.data.BackLays[0].Price);
            	       $('#second_lgai_input').val(obj.data.BackLays[3].Price);
            	   }
        	   }
        	   //else if(obj.responseType=='11'){
        	   else {
    // alert('test');
    $("#session_table").append('<tr><td class="subtitle"><h6>'+obj.data.Name+'</h6><span>Session Limit : 1K</span></td><td><span class="text-blue">00</span></td><td><span class="text-red">0</span></td></tr>');
        	   }
	    }else{
	        console.log('fail') ;
	    }
		var msg = $('<pre>').text(data);
		if (type === 'SENT') {
			msg.addClass('sent');
		}
// 		var messages = $('#messages');
// 		messages.append(msg);
		
// 		var msgBox = messages.get(0);
// 		while (msgBox.childNodes.length > 1000) {
// 			msgBox.removeChild(msgBox.firstChild);
// 		}
// 		msgBox.scrollTop = msgBox.scrollHeight;
	}

	WebSocketClient = {
		init: function() {
			serverUrl = $('#serverUrl');
			connectionStatus = $('#connectionStatus');
// 			sendMessage = $('#sendMessage');
			connectButton = $('#connectButton');
			disconnectButton = $('#disconnectButton'); 
			sendButton = $('#sendButton');
			
// 			connectButton.click(function(e) {
				// close();
				open();
					var msg = $('#sendMessage').val();
				addMessage(msg, 'SENT');
				ws.send(msg);
// 			});
		
// 			disconnectButton.click(function(e) {
			
// 			});
			
			sendButton.click(function(e) {
				var msg = $('#sendMessage').val();
				addMessage(msg, 'SENT');
				ws.send(msg);
			});
			
			$('#clearMessage').click(function(e) {
				clearLog();
			});
			
			var isCtrl;
			sendMessage.keyup(function (e) {
				if(e.which == 17) isCtrl=false;
			}).keydown(function (e) {
				if(e.which == 17) isCtrl=true;
				if(e.which == 13 && isCtrl == true) {
					sendButton.click();
					return false;
				}
			});
		}
	};
}

$(function() {
	WebSocketClient.init();
});
    
</script>
</body>

</html>