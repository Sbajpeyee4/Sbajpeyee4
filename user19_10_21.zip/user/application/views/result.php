<!DOCTYPE html>
<html lang="en">
 <head>
    <title>777HUB</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="<?=base_url()?>assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?=base_url()?>assets/css/style.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  </head>
<body class="bg-light">
  <!-- ======= Header ======= -->
  <header>
  <nav class="navbar navbar-expand-lg navbar-light">
  <div class="container-fluid">
    <div class="navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="navbar-brand" href="index"><img src="<?=base_url()?>assets/images/logo.png"></a>
        </li>
        <li class="nav-item text-center cointext">
         <h5>TESTING </h5>
         <h5><span>Coins : <span>5910</span></span></h5>
        </li>
        <li class="nav-item nav-links">
        <a href="login">
        <span>
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-box-arrow-in-right" viewBox="0 0 16 16">
        <path fill-rule="evenodd" d="M6 3.5a.5.5 0 0 1 .5-.5h8a.5.5 0 0 1 .5.5v9a.5.5 0 0 1-.5.5h-8a.5.5 0 0 1-.5-.5v-2a.5.5 0 0 0-1 0v2A1.5 1.5 0 0 0 6.5 14h8a1.5 1.5 0 0 0 1.5-1.5v-9A1.5 1.5 0 0 0 14.5 2h-8A1.5 1.5 0 0 0 5 3.5v2a.5.5 0 0 0 1 0v-2z"/>
        <path fill-rule="evenodd" d="M11.854 8.354a.5.5 0 0 0 0-.708l-3-3a.5.5 0 1 0-.708.708L10.293 7.5H1.5a.5.5 0 0 0 0 1h8.793l-2.147 2.146a.5.5 0 0 0 .708.708l3-3z"/>
      </svg>
      </span>
       <h5>Logout</h5>
          </a>
        </li>
      </ul>
  
    </div>
  </div>
</nav>
  </header>
<a href="completegame" class="backbtn">BACK TO COMPLETE GAMES</a>
  <main class="p-0">
   <div class="container-fluid">
  <section>
    <div class="row">
    <div class="col-sm-12 p-0">
    <div class="tabletr">
    <div class="tableheader bg-red">
      <p>1169 LANCASHIRE V YORKSHIRE (T-20 BLAST) 2021-07-17 21:30:00</p>
    </div>
    <div class="tableheader bg-blue">
      <p>Match Bet(s) Won By : LANCASHIRE</p>
    </div>
    <div class="table-responsive">
     <table class="table mb-0">
     <tbody>
       <tr class="bg-lightblue">
         <td class="text-right"> Rate </td>
         <td class="text-right"> Amount </td>
         <td class="text-center"> Mode </td>
         <td class="text-center"> Team </td>
         <td class="text-right"> LANCASHIRE </td>
         <td class="text-right"> YORKSHIRE </td>
       </tr>
       <tr>
         <td class="text-right"> 0.09   </td>
         <td class="text-right"> 1000 </td>
         <td class="text-center"> K </td>
         <td class="text-center"> LANCASHIRE </td>
         <td class="text-right"> -90.00   </td>
         <td class="text-right"> 1000.00 </td>
       </tr>
       <tr>
         <td colspan="6" class="text-red text-center  ">You Lost 90</td>
       </tr>
     </tbody>
     </table>
        </div>
      <div class="tableheader bg-blue">
      <p>Session Bet(s)</p>
    </div>
    <div class="table-responsive">
    <table class="table">
       <tbody>
        <tr class="bg-lightblue">
         <td class="text-left"> Session </td>
         <td class="text-right"> Rate </td>
         <td class="text-right"> Amount </td>
         <td class="text-right"> Runs </td>
         <td class="text-center"> Mode </td>
         <td class="text-center"> Dec </td>
       </tr> 
        <tr>
         <td class="text-left"> 10 OVER RUNS IRE </td>
         <td class="text-right"> 1.0   </td>
         <td class="text-right"> 500 </td>
         <td class="text-right"> 49 </td>
         <td class="text-center"> YES </td>
         <td class="text-center"> 49 </td>
       </tr>
      <tr>
        <td colspan="6" class="text-center text-blue">You Won 500</td>
      </tr>
       </tbody>
    </table>
  </div>
   <div class="tableheader bg-blue">
      <p>Match Session Plus Minus</p>
    </div>
    <div class="table-responsive">
    <table class="table">
       <tbody>
        <tr>
        <td colspan="6" class="text-center text-blue">You Win 1000 Coins</td>
      </tr>
       </tbody>
    </table>
  </div> 
  <div class="tableheader bg-blue">
      <p>My Commission</p>
    </div>
    <div class="table-responsive">
    <table class="table">
       <tbody>
        <tr>
        <td colspan="6" class="text-center text-blue">0.0</td>
      </tr>
       </tbody>
    </table>
  </div>
  <div class="tableheader bg-blue">
      <p>Amount After Comm.</p>
    </div>
    <div class="table-responsive">
    <table class="table">
       <tbody>
        <tr>
        <td colspan="6" class="text-center text-blue">You Won 1000.0 Coins.</td>
      </tr>
       </tbody>
    </table>
  </div> 
  <div class="tableheader bg-blue">
      <p>Mob. App. Charges</p>
    </div>
    <div class="table-responsive">
    <table class="table">
       <tbody>
        <tr>
        <td colspan="6" class="text-center text-red">You Lost 0 Coins.</td>
      </tr>
       </tbody>
    </table>
  </div>
  <div class="tableheader bg-blue">
      <p>Net Plus Minus</p>
    </div>
    <div class="table-responsive">
    <table class="table">
       <tbody>
        <tr>
        <td colspan="6" class="text-center text-blue">You Won 1000.00 Coins</td>
      </tr>
       </tbody>
    </table>
  </div>
   </div>
  </div>
  </div>
    </section>   
      </div>
   </main><!-- End #main -->
   <a href="completegame" class="backbtn">BACK TO COMPLETE GAMES</a>
  <!-- ======= Footer ======= -->
  <footer>
  <div class="footer">
    Copy Right @ 777HUB
  </div>
  </footer>
</body>

</html>