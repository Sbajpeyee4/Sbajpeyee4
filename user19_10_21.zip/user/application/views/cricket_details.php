<!DOCTYPE html>
<html lang="en">
 <head>
    <title>777 HUB</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <meta meta name="viewport" content="width=device-width, user-scalable=no" />
   <link href="<?=base_url()?>assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?=base_url()?>assets/css/style.css" rel="stylesheet">
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
     <style>
.teamname{
width:54%;
}
.rate_name{
width:23%;
}
.block_table td {
    padding: 0px !important;
}
.block_table td label {
    display: block;
    padding: 0.8rem;
    cursor: pointer;
}
     </style>
  </head>

<body class="bg-light">
  <!-- ======= Header ======= -->
  <header>
  <nav class="navbar navbar-expand-lg navbar-light">
  <div class="container-fluid">
    <div class="navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="navbar-brand" href="../index"><img src="<?=base_url()?>assets/images/logo.png"></a>
        </li>
        <li class="nav-item text-center cointext">
         <h5><?=$user_data[0]->client_name?>  </h5>
           <h5><span>Coins : <span id='coins'><?=round($user_data[0]->current_limit,2)?></span></span></h5>
         <!--<h6><span>Used Coin : <span><?=round($used_coin[0]['used'],2)?></span></span></h6>-->
         <!--<h6><span>Session P/M : <span>0</span></span></h6>-->
        </li>
        <li class="nav-item nav-links">
        <a href="https://777hub.in/user/login">
        <span>
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-box-arrow-in-right" viewBox="0 0 16 16">
        <path fill-rule="evenodd" d="M6 3.5a.5.5 0 0 1 .5-.5h8a.5.5 0 0 1 .5.5v9a.5.5 0 0 1-.5.5h-8a.5.5 0 0 1-.5-.5v-2a.5.5 0 0 0-1 0v2A1.5 1.5 0 0 0 6.5 14h8a1.5 1.5 0 0 0 1.5-1.5v-9A1.5 1.5 0 0 0 14.5 2h-8A1.5 1.5 0 0 0 5 3.5v2a.5.5 0 0 0 1 0v-2z"/>
        <path fill-rule="evenodd" d="M11.854 8.354a.5.5 0 0 0 0-.708l-3-3a.5.5 0 1 0-.708.708L10.293 7.5H1.5a.5.5 0 0 0 0 1h8.793l-2.147 2.146a.5.5 0 0 0 .708.708l3-3z"/>
      </svg>
      </span>
       <h5>Logout</h5>
          </a>
        </li>
      </ul>
  
    </div>
  </div>
</nav>
  </header>
  <!-- End Header -->
  <body>
 <button id="shoTv" class="backbtn text-uppercase font-weight-bold"><img src="<?=base_url()?>assets/images/tv.png"><span>Show Tv</span></button>
 <div class="toggleDiv">
  <video width="100%" height="300" autoplay controls="">
  <source src="" type="video/mp4">
  <source src="" type="video/ogg">
</video>
 </div>
  <main class="p-0">
   <div class="container-fluid">
    <section>
    <div class="row">
    <div class="col-sm-12 p-0">
    <div class="table-responsive">
     <table class="table tablerun mt-2 mb-0">
       <tbody>
         <tr>
           <td class="w-35">
            <div>
            <h5>( )*</h5>
            <h5>( )*</h5>
            <h5>BOWLER :</h5>
            </div>
            </td>
           <td class="w-35">
            <div>
            <h5>AAAA (NAN)</h5>
            <h5>BBBB (NAN)</h5>
            <h5>6 BALLS :</h5>
            </div>
          </td>
           <td class="w-35">
             <div><img src="<?=base_url()?>assets/images/blank.jpg" style="width:43px;"></div>
           </td>
         </tr>
       </tbody>
     </table>
   </div>
    </div>
    <div class="col-sm-12 mt-2 p-0 tableteam">
         <input type='hidden' id='rate_input' value='' >
         <input type='hidden' id='session_rate_input' value='' >
         <input type='hidden' id='session_run_input' value='' >
         <input type='hidden' id='session_id' value='' >
         <input type='hidden' id='session_name' value='' >
    <div class="table-responsive">
     <table class="table text-center block_table">
       <tbody>
        <tbody>
          <tr>
            <td class="thheader teamname">
              TEAM<br>
              <!--Max : 200K-->
            </td>
           
            
            <td class="thheader rate_name">
                 LAGAI
            </td>
             <td class="thheader rate_name">
                 KHAI  
            </td>
          </tr>
          <!--<tr>-->
          <!--  <td><span>AAAA :</span><span class="text-blue">0</span></td>-->
          <!--  <td><span class="text-blue alert">0.00</span></td>-->
          <!--  <td><span class="text-red alert">0.00</span></td>-->
          <!--</tr>-->
          <!--  <tr>-->
          <!--  <td><span>BBBB :</span><span class="text-blue">0</span></td>-->
          <!--  <td><span class="text-blue alert ">0.00</span></td>-->
          <!--  <td><span class="text-red alert">0.00</span></td>-->
          <!--</tr>-->
            <tr>
              <input  type='hidden' id='bet_type' value='' >
            <td><span><?=$match_data[0]->first_team_id ?> :</span><span class="text-blue">0</span></td>
            <td onclick="firstlgaiFunction()"> <input  type='hidden'  id='first_lgai_input' value='0.05' ><label class="text-blue betting" for="amount" id='first_lgai'   >0.05</label></td>
            <td onclick="firstkhaiFunction()"><input  type='hidden' id='first_khai_input' value='0.05' ><label class="text-red  betting" for="amount" id='first_khai'  >0.05</label></td>
          </tr>
            <tr>
            <td><span><?=$match_data[0]->second_team_id ?> :</span><span class="text-blue">0</span></td>
            <td onclick="secondlgaiFunction()"> <input  type='hidden' id='second_lgai_input' value='0.06' > <label class="text-blue betting" for="amount" id='second_lgai' >0.06</label></td>
            <td onclick="secondkhaiFunction()"> <input type='hidden' id='second_khai_input' value='0.08' ><label class="text-red  betting" for="amount" id='second_khai'>0.08</label></td>
          </tr>
        </tbody>
       </tbody>
     </table>
     <table class="table text-center block_table" id='sesson'>
        <thead>
            <tr>
                <td class="thheader teamname">
                    SESSION
                </td>
                <td class="thheader rate_name">
                    NOT
                </td>
                <td class="thheader rate_name">
                    YES
                </td>
            </tr>
        </thead>
        <tbody >
          <!--<tr>-->
          <!--      <td class="subtitle"><h6>6 OVER RUN AAAA</h6>-->
          <!--        <span>Session Limit : 1K</span></td>-->
          <!--      <td><span class="text-blue mysess betting" style="display: block;" data ='165' sess='6 OVER RUN AAAA' >160</span> <span class="text-blue mysess betting"  style="display: block; opacity: .5;" >1.00</span></td>-->
          <!--      <td><span class="text-red mysess_no betting" data ='165' sess='6 OVER RUN AAAA' >00</span></td>-->
          <!--    </tr>-->
            
              <tr id ="sess" >
                  <td class="subtitle" >
                      <h6>6 OVER RUN AAAA</h6><span>Session Limit : 1K</span></td>
                     <td onClick='testfun(12)'  > <label for="amount" >  <span class="text-red  " id ="sesslgairun12"  style="display: block; " >145</span><span  style="display: block; opacity: .5;" class="text-red mysess_no betting" id ="sesslgai12"  data ="" sess="6 OVER RUN AAAA">1.10</span></label></td>
                      
                      <td onClick="testfunyes(12)"><label for="amount" ><span class="text-blue" id ="sesskhairun12"  style="display: block;" >145</span><span style="display: block;  opacity: .5;" class="text-blue mysess betting btnNew"  id ="sesskhai12"  data ="12" sess="6 OVER RUN AAAA" >0.90</span></label> </td>
               </tr>
         
          <!--<tr >-->
          <!--  <td class="subtitle"><h6>10 OVER RUN AAAA</h6>-->
          <!--      <span>Session Limit : 1K</span></td>-->
          <!--      <td onClick='testfun()' ><span class="text-blue mysess betting" data ='165' sess='10 OVER RUN AAAA' >160</span></td>-->
          <!--      <td><span class="text-red mysess_no betting" data ='165' sess='10 OVER RUN AAAA' >00</span></td>-->
          <!--</tr>-->
        </tbody>
     </table>
   </div>
    </div>
    <div class="col-sm-12 mt-2 p-0 bluetable">
    <div class="table-responsive">
     <table class="table text-center" border="0"> 
       <tbody>
         <tr>
           <td >AMOUNT</td>
           <td class="m_input"><input type="text" name="" readonly id="amount" ></td>
           <td><input type="text" name="" class="amount" id="progressBar" readonly=""></td>
           <td onclick="myFunction()">Done</td>
         </tr>
       </tbody>
     </table>
    </div>
   </div>
     <div class="col-sm-12 mt-2 p-0 lasttable">
      <div class="table-responsive">
      <table class="table">
        <tbody>
          <tr>
            <td class="text-center">Sr.</td>
            <td class="text-center">Session Name</td>
            <td class="text-right">Rate</td>
            <td class="text-right">Run</td>
            <td class="text-right">Amount</td>
            <td class="text-center">Mode</td>
          </tr>
          <?php $j=1; foreach($sess_bat_data as $sbat){ ?>
          <tr>
            <td ><?=$j?></td>
            <td ><?php $sess = $this->cm->get_data('session_rate_table',['rate_id'=>$sbat->session_id]); echo $sess[0]->session_name; ?></td>
            <td ><?=$sbat->rate?></td>
            <td ><?=$sbat->run?></td>
            <td ><?=$sbat->amount?></td>
            <td ><?=$sbat->bet_type?></td>
            <!--<td ><?php //$bat->fav_team ?></td>-->
          </tr>
          <?php $j++; } ?>
        </tbody>
      </table>
     </div>
    </div>
     <div class="col-sm-12 mt-2 p-0 lasttable">
      <div class="table-responsive">
      <table class="table">
        <tbody>
            
          <tr>
            <td class="text-center">Sr.</td>
            <td class="text-right">Rate</td>
            <td class="text-right">Amount</td>
            <td class="text-center">Mode</td>
            <td class="text-right">Team</td>
          </tr>
          <?php $i=1; foreach($bat_data as $bat){ ?>
          <tr>
            <td ><?=$i?></td>
            <td ><?=$bat->rate?></td>
            <td ><?=$bat->amount?></td>
            <td ><?=$bat->bet_type?></td>
            <td ><?=$bat->fav_team?></td>
          </tr>
          <?php $i++; } ?>
        </tbody>
      </table>
     </div>
    </div>
  </div>
    </section>   
      </div>
   </main><!-- End #main -->
<a href="https://777hub.in/user/home/inplay" class="backbtn" onclick="goBack()" >BACK TO MAIN MENU</a>
  <!-- ======= Footer ======= -->
  <footer>
  <div class="footer">
    Copy Right @ 777HUB
  </div>
  </footer>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
//  var sess2 =  '<tr id ="sess"><td class="subtitle"><h6></h6><span>Session Limit : 1K</span></td><td><span class="text-red  " id ="sesslgairun"  style="display: block; " ></span><label for="amount" style="display: block; opacity: .5;" class="text-red mysess_no betting" id ="sesslgai"  data ="" sess=""></label></td><td><span class="text-blue" id ="sesskhairun"  style="display: block;" ></span><label for="amount" style="display: block;  opacity: .5;" class="text-blue mysess betting btnNew"  id ="sesskhai"  data ="" sess="" ></label> </td></tr>';
//   console.log(sess2);     
$(document).ready(function(){
  $("#shoTv").click(function(){
     $('#shoTv span').text($(this).text() == 'Hide TV' ? 'Show Tv' : 'Hide TV');
    $(".toggleDiv").slideToggle(); 
  });
   $(".alert").click(function(){
    alert('Not Find any run or rate ');
  });
});
    var first_id = '<?=$match_data[0]->first_team_id  ?>'
    var second_id = '<?=$match_data[0]->second_team_id  ?>'
	    
function my_function(){
    //  alert('test');
 $.ajax({    
            type: 'post',
            url: "<?php echo base_url('home/testapi/').$match_data[0]->match_code;?>",
            // data:{match_id:match_id,bet_type:bet_type,second_team:second_team,first_team:first_team,amount:amount,fav_team:fav_team,rate:rate,mode:mode},
            
            success: function (result) {
                // console.log(result);
              var res =  $.parseJSON(result);
             
              var tessess = res.t3;
              if(res.t2.length > 0){
                   var tes = res.t2[0].bm1;
                      console.log(tes[0].b1);
              tes.forEach(myFunction_set);
              }else{
            $('#first_khai').html('0.00');
	       $('#first_khai_input').val('0.00');
	       $('#first_lgai').html('0.00');
	       $('#first_lgai_input').val('0.00');
	        $('#second_khai').html('0.00');
	       $('#second_khai_input').val('0.00');
	       $('#second_lgai').html('0.00');
	       $('#second_lgai_input').val('0.00');
              }
                if(tes[0].b1<=0 && tes[0].l1<=0 && tes[1].b1<=0 && tes[1].l1<=0 ){
	                  $('.mysess_no').html('0.00');
	                  $('.mysess').html('0.00');
                    // $("#sesson tr").remove();
                    //   $("#sesson").find("tr:gt(0)").remove();
                }else{
                    tessess.forEach(myFunction_set_session);

                }
            }
      });
}
// setInterval(my_function,5000);
// my_function();
function myFunction_set(item, index) {
    //   console.log(item);
    var first_id = '<?=$match_data[0]->first_team_id  ?>'
	var second_id = '<?=$match_data[0]->second_team_id  ?>'
	    
 
  if(item.nat==first_id){
//         console.log(first_id);
//   console.log(item.nat);
//       console.log(item.b1);
//   $('#first_khai').html('test');
	       $('#first_khai').html((item.l1/100).toFixed(2));
	       $('#first_khai_input').val((item.l1/100).toFixed(2));
	       $('#first_lgai').html((item.b1/100).toFixed(2));
	       $('#first_lgai_input').val((item.b1/100).toFixed(2));
  }else{
//       console.log(second_id);
//   console.log(item.nat);
        // $('#second_khai').html('test');
    //   console.log(item.b1);
        // console.log(item.b1);
      $('#second_khai').html((item.l1/100).toFixed(2));
	       $('#second_khai_input').val((item.l1/100).toFixed(2));
	       $('#second_lgai').html((item.b1/100).toFixed(2));
	       $('#second_lgai_input').val((item.b1/100).toFixed(2));
  }
}
function myFunction_set_session(item, index) {
    var sess = '<tr><td class="subtitle"><h6>6 OVER RUN AAAA</h6><span>Session Limit : 1K</span></td><td><span class="text-blue" >00</span></td><td><span class="text-red">00</span></td></tr>';
    // var first_id = '<?=$match_data[0]->first_team_id  ?>'
	// var second_id = '<?=$match_data[0]->second_team_id  ?>'
//   console.log(item);
  
    //   console.log(item);
    //   if()
    // alert('#sess'+item.sid);
  
    // if(!$('#sesson'+item.sid).hasClass('.sess'+item.sid)) { 
        //   alert('.sess'+item.sid);
         var name = 'sess'+item.sid;
    if($("#" + name).length == 0) {
        if(item.gstatus=='SUSPENDED'){
            $("#" + name).remove()
        }else{
        // var sess = '<tr id ="sess'+item.sid+'"><td class="subtitle"><h6>'+item.nat+'</h6><span>Session Limit : 1K</span></td><td><span class="text-blue mysess betting btnNew"  id ="sesskhai'+item.sid+'"  data ="'+item.sid+'" sess="'+item.nat+'" >'+item.b1+'</span></td><td><span class="text-red mysess_no betting" id ="sesslgai'+item.sid+'"  data ="'+item.sid+'" sess="'+item.nat+'">'+item.l1+'</span></td></tr>';
        var sess =  '<tr id ="sess'+item.sid+'"><td class="subtitle"><h6>'+item.nat+'</h6><span>Session Limit : 1K</span></td><td onClick="testfun('+item.sid+')"><label for="amount"><span class="text-red  " id ="sesslgairun'+item.sid+'"  style="display: block; " >'+item.l1+'</span><span style="display: block; opacity: .5;" class="text-red mysess_no betting" id ="sesslgai'+item.sid+'"  data ="'+item.sid+'" sess="'+item.nat+'">'+(item.ls1/100).toFixed(2)+'</span></label></td><td onClick="testfunyes('+item.sid+')"><label for="amount"><span class="text-blue" id ="sesskhairun'+item.sid+'"  style="display: block;" >'+item.b1+'</span><span style="display: block;  opacity: .5;" class="text-blue mysess betting btnNew"  id ="sesskhai'+item.sid+'"  data ="'+item.sid+'" sess="'+item.nat+'" >'+(item.bs1/100).toFixed(2)+'</span></label> </td></tr>';
        $('#sesson tr:last').after(sess);
        }
}else{
     var sesskhai = 'sesskhai'+item.sid;
     var sesslgai = 'sesslgai'+item.sid;
     var sesslgairun = 'sesslgairun'+item.sid;
     var sesskhairun = 'sesskhairun'+item.sid;
    $("#" + sesslgairun).html(item.l1);
    $("#" + sesskhairun).html(item.b1);
    $("#" + sesskhai).html((item.bs1/100).toFixed(2));
    $("#" + sesslgai).html((item.ls1/100).toFixed(2));
    
}
        
        // }else{
         
            // }
  
//   $(".sesson" ).append(sess);
//   console.log(first_id);
  
//   if(item.nat==first_id){
// 	       $('#first_khai').html(item.b1);
// 	       $('#first_khai_input').val(item.b1);
// 	       $('#first_lgai').html(item.l1);
// 	       $('#first_lgai_input').val(item.l1);
//   }else{
//       $('#second_khai').html(item.b1);
// 	       $('#second_khai_input').val(item.b1);
// 	       $('#second_lgai').html(item.l1);
// 	       $('#second_lgai_input').val(item.l1);
      
//   }
  
}
 
// function sessionbet(this) {
//     var tets  = $(this).html();
//     alert(tets+"test");
// //  console.log(tets);
  
// }

function testfun(test){
    var rate  =  $("#sesslgai" + test).html();
    var run = $("#sesslgairun" + test).html();
    $("#session_id").val(test);
    $("#bet_type").val('session_no');
  var te =   $("#sesslgai" + test).attr('sess');
    $("#session_name").val(te);
    $("#session_rate_input").val(rate);
    $("#session_run_input").val(run);
     if(rate > 0){
        add_counter(test);
     }else{
         alert('Invalid Rate');
     }
//   var test =   $("#sesslgai" + test).attr('data');
}
function testfunyes(test){
    var rate  =  $("#sesskhai" + test).html();
    var run = $("#sesskhairun" + test).html();
    $("#session_id").val(test);
    $("#bet_type").val('session_yes');
  var te =   $("#sesskhai" + test).attr('sess');
    $("#session_name").val(te);
    $("#session_rate_input").val(rate);
    $("#session_run_input").val(run);
    
    if(rate > 0){
        add_counter(test);
     }else{
         alert('Invalid Rate');
     }
//   var test =   $("#sesslgai" + test).attr('data');
}
// $('.mysess').click(function(){
//     alert(test);
//     var rate  = $(this).html();
//     $("#bet_type").val('session_yes');
//   var test =   $(this).attr('data');
//   var te =   $(this).attr('sess');
//     $("#session_id").val(test);
//     $("#session_name").val(te);
//     $("#session_rate_input").val(rate);
    
// });

// $('.mysess_no').click(function(){
//     var rate  = $(this).html();
//     $("#bet_type").val('session_no');
//   var test =   $(this).attr('data');
//   var te =   $(this).attr('sess');
//     $("#session_id").val(test);
//     $("#session_name").val(te);
//     $("#session_rate_input").val(rate);
// });
// $('body').on('click', '.mysess_no',function(){
//     var rate  = $(this).html();
//     $("#bet_type").val('session_no');
//   var test =   $(this).attr('data');
//   var te =   $(this).attr('sess');
//   var run = $("#sesslgairun" + test).html();
//     $("#session_id").val(test);
//     $("#session_name").val(te);
//     $("#session_rate_input").val(rate);
//     $("#session_run_input").val(run);
// });
$('body').on('click', '.mysess',function(){
  var rate  = $(this).html();
    $("#bet_type").val('session_yes');
  var test =   $(this).attr('data');
  var te =   $(this).attr('sess');
    var run = $("#sesskhairun" + test).html();
    $("#session_id").val(test);
    $("#session_name").val(te);
    $("#session_rate_input").val(rate);
    $("#session_run_input").val(run);
});
</script>
<script>
 
function secondkhaiFunction() {
  $("#bet_type").val('second_khai');
   var test =  $('#second_khai_input').val();
  $("#rate_input").val(test);
  
}
 
function secondlgaiFunction() {
  $("#bet_type").val('second_lgai'); 
  var test =  $('#second_lgai_input').val();
  $("#rate_input").val(test);
}

function firstkhaiFunction() {
  $("#bet_type").val('first_khai'); 
  var test =  $('#first_khai_input').val();
  $("#rate_input").val(test);
}

function firstlgaiFunction() {
    
  $("#bet_type").val('first_lgai');
  var test =  $('#first_lgai_input').val();
  $("#rate_input").val(test);
  
}
function myFunction() {
var bet_type =  $("#bet_type").val(); 
var match_id =  '<?=$match_data[0]->match_code  ?>'; 
 var amount =  $("#amount").val(); 
   var coins =  $("#coins").html(); 
   var fixrate =  $("#rate_input").val(); 
    coins =    parseInt(coins);
   var first_team =  '<?=$match_data[0]->first_team_id ?>'; 
   var second_team =  '<?=$match_data[0]->second_team_id ?>'; 
if(bet_type=='session_yes' || bet_type=='session_no'  ){
    
    var session_name =  $("#session_name").val(); 
   var session_id =  $("#session_id").val(); 
   if(bet_type=='session_yes'){
        var mode ='yes';
   }else {
        var mode ='no';
        }
        var rate =  $("#session_rate_input").val(); 
        var run =  $("#session_run_input").val(); 
  if(coins>=amount && amount > 0){
    // alert(amount);
        $.ajax({    
            type: 'post',
            url: "<?php echo base_url('home/add_sess_bat');?>",
            data:{match_id:match_id,bet_type:bet_type,session_name:session_name,session_id:session_id,amount:amount,rate:rate,mode:mode,run:run},
            success: function (result) {
                $("#session_rate_input").val('');
                console.log(result);
                alert('Successfully registered');
                location.reload(); 
            }
      });
   }else{
       alert('insufficient coins or Amount');
       $("#rate_input").val('');
   }
       
   }else{
   if(bet_type=='first_khai'){
        var rate =  $("#first_khai_input").val(); 
        var mode ='khai';
        var fav_team = '<?=$match_data[0]->first_team_id ?>';
   }else if(bet_type=='first_lgai'){
        var mode ='lagai';
        var rate =  $("#first_lgai_input").val();
        var fav_team = '<?=$match_data[0]->first_team_id ?>';
   }else if(bet_type=='second_khai'){
        var mode ='khai';
        var rate =  $("#second_khai_input").val(); 
        var fav_team = '<?=$match_data[0]->second_team_id ?>';
   }else if(bet_type=='second_lgai'){
        var mode ='lagai';
        var rate =  $("#second_lgai_input").val(); 
        var fav_team = '<?=$match_data[0]->second_team_id ?>';
   } 
   
  
   if(coins>=amount && amount > 0){
     
  $.ajax({    
            type: 'post',
            url: "<?php echo base_url('home/add_bat');?>",
            data:{match_id:match_id,bet_type:bet_type,second_team:second_team,first_team:first_team,amount:amount,fav_team:fav_team,rate:fixrate,mode:mode},
            
            success: function (result) {
                $("#rate_input").val('');
                console.log(result);
                location.reload(); 
            }
      });
   }else{
       alert('insufficient coins or Amount');
       $("#rate_input").val('');
   }
   
}
}

// $(document).ready(function(){
//   $(".betting").click(function(){
//       var rate = $(this).text();
//     if(rate > 0){
//       $("#amount").removeAttr("readonly");
//       var counter = 10;
// var interval = setInterval(function() {
//     counter--;
//      document.getElementById("progressBar").value = counter 
//     // Display 'counter' wherever you want to display it.
//     if (counter == 0) {
//     document.getElementById("amount").value = ""; 
//       $('#amount').attr('readonly', true);
//          $("#rate_input").val('');
//         alert('Time Out');
//         clearInterval(interval);
//     }
// }, 1000);
//         }else {
//           alert('Invalid Rate');
//       }
//   });
// }); 
function add_counter(test){
   
      $("#amount").removeAttr("readonly");
      var counter = 10;
var interval = setInterval(function() {
    counter--;
     document.getElementById("progressBar").value = counter 
    // Display 'counter' wherever you want to display it.
    if (counter == 0) {
    document.getElementById("amount").value = ""; 
       $('#amount').attr('readonly', true);
         $("#rate_input").val('');
        alert('Time Out');
        clearInterval(interval);
    }
}, 1000);
        
}
$('body').on('click', '.betting', function () {
      var rate = $(this).text();
    if(rate > 0){
      $("#amount").removeAttr("readonly");
      var counter = 10;
var interval = setInterval(function() {
    counter--;
     document.getElementById("progressBar").value = counter 
    // Display 'counter' wherever you want to display it.
    if (counter == 0) {
    document.getElementById("amount").value = ""; 
       $('#amount').attr('readonly', true);
         $("#rate_input").val('');
        alert('Time Out');
        clearInterval(interval);
    }
}, 1000);
        }else {
          alert('Invalid Rate');
      }
   });
</script>
</body>

</html>