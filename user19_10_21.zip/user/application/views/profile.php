<!DOCTYPE html>
<html lang="en">
 <head>
    <title>777HUB</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="<?=base_url()?>assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?=base_url()?>assets/css/style.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  </head>

<body class="bg-light">
  <!-- ======= Header ======= -->
  <header>
  <nav class="navbar navbar-expand-lg navbar-light">
  <div class="container-fluid">
    <div class="navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="navbar-brand" href="index"><img src="<?=base_url()?>assets/images/logo.png"></a>
        </li>
        <li class="nav-item text-center cointext">
         <h5><?=$cliend_details[0]->client_name?> </h5>
         <h5><span>Coins : <span><?=$cliend_details[0]->current_limit?></span></span></h5>
        </li>
        <li class="nav-item nav-links">
        <a href="login">
        <span>
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-box-arrow-in-right" viewBox="0 0 16 16">
        <path fill-rule="evenodd" d="M6 3.5a.5.5 0 0 1 .5-.5h8a.5.5 0 0 1 .5.5v9a.5.5 0 0 1-.5.5h-8a.5.5 0 0 1-.5-.5v-2a.5.5 0 0 0-1 0v2A1.5 1.5 0 0 0 6.5 14h8a1.5 1.5 0 0 0 1.5-1.5v-9A1.5 1.5 0 0 0 14.5 2h-8A1.5 1.5 0 0 0 5 3.5v2a.5.5 0 0 0 1 0v-2z"/>
        <path fill-rule="evenodd" d="M11.854 8.354a.5.5 0 0 0 0-.708l-3-3a.5.5 0 1 0-.708.708L10.293 7.5H1.5a.5.5 0 0 0 0 1h8.793l-2.147 2.146a.5.5 0 0 0 .708.708l3-3z"/>
      </svg>
      </span>
       <h5>Logout</h5>
          </a>
        </li>
      </ul>
  
    </div>
  </div>
</nav>
  </header>
  <a href="index" class="backbtn">BACK TO MAIN MENU</a>
  <main id="" class="p-0">
   <div class="container-fluid">
   <div class="row">
     <div class="col-sm-12 p-0 profile-table">
      <form>
      <div class="table-responsive">
      <table class="table">
        <tbody>
          <tr>
            <td colspan="3" class="bg-purpule w-35"> 
              RATE INFORMATION
            </td>
          </tr>
          <tr>
            <td>Rate Difference :</td>
            <td class="w-35 text-center">
              <select>
              <option value="">2</option>
              <option value="">3</option>
              <option value="">4</option>
              <option value="">5</option>
            </select>
          </td>
          <td class="w-35"><button type="submit" class="btnupdate">UPDATE</button></td>
          </tr>
        </tbody>
      </table> 
    </div>
    </form>
     </div>
     <div class="col-sm-12 p-0 profile-table">
      <div class="table-responsive">
      <table class="table">
        <tbody>
          <tr>
            <td colspan="2" class="bg-purpule w-35"> 
              PERSONAL INFORMATION
            </td>
          </tr>
          <tr>
            <td class="w-50">Client Code :  </td>
          <td class="w-50"> C58531</td>
          </tr>
           <tr>
            <td class="w-50">Client Name :</td>
          <td class="w-50">   TESTING</td>
          </tr>
           <tr>
            <td class="w-50">Contact No :</td>
          <td class="w-50">   0</td>
          </tr>
           <tr>
            <td class="w-50">Date Of Joining :</td>
          <td class="w-50">   2021-07-13 09:55:17.0</td>
          </tr> 
          <tr>
            <td class="w-50">Address :</td>
          <td class="w-50"> India</td>
          </tr>
        </tbody>
      </table> 
    </div>
     </div>
      <div class="col-sm-12 p-0 profile-table">
        <div class="table-responsive">
      <table class="table">
        <tbody>
          <tr>
            <td colspan="2" class="bg-purpule w-35"> 
              COMPANY INFORMATION
            </td>
          </tr>
          <tr>
            <td class="w-50">HELP LINE NO :</td>
          <td class="w-50"> </td>
          </tr>
        </tbody>
      </table>
      </div> 
     </div>
   </div> 
    </div>
   </main><!-- End #main -->
 <button class="backbtn" onclick="goBack()">BACK TO MAIN MENU</button>
  <!-- ======= Footer ======= -->
  <footer>
  <div class="footer">
    Copy Right @ 777HUB
  </div>
  </footer>
<script>
function goBack() {
  window.history.back();
}
</script>
</body>

</html>