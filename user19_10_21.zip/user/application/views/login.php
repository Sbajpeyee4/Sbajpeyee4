<!DOCTYPE html>
<html>

  <head>
    <title>777HUB</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="<?=base_url()?>assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?=base_url()?>assets/css/style.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  </head>
  <body>
    <div class="container">
      <div class="page-layout-login">
        <div class="row justify-content-center">
          <div class="col-sm-5 pd-39">
            <h1>777HUB</h1>
            <h6>Sign in</h6>
            <form action="<?php echo base_url();?>login/log" method='post'>
              <div class="form-input">
                <div class="form-floating-static mb-4">
                  <small></small>
                  <input type="text" value='C' name='id' class="form-control" id="floatingInput" placeholder="" required>
                  <label for="floatingInput">Client Code*</label>
                </div>
                <div class="form-floating">
                  <input type="password" name='password' class="form-control" id="floatingPassword" placeholder="Password" required="" autocomplete="off">
                  <label for="floatingPassword">Password*</label>
                </div>
                <div class="chebox mb-2 mt-4">
                  <label>
                    <input class="form-check-input mt-0" type="checkbox" value="" aria-label="Checkbox for following text input" autocomplete="off">
                    <span>Remember me</span>
                  </label>
                </div>
                <button type="submit" id="login-btn" class="btn-login btn-hover">  <div id="circle" class="circle"></div> Sign In
                </button>
              </div>
            </form>
          </div>
          <div class="copyright text-center">
            <h5>Copyright © <a href="http://99hub.in/">777HUB.in</a> 2021.</h5>
          </div>
        </div>
      </div>
    </div>
    <script src="<?=base_url()?>assets/js/bootstrap.bundle.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
$(document).ready(function() {
  // Flash functions
 
  $('#login-btn').mousedown(function() {
    $(this).addClass('hold-mouse')
    console.log('event', event)
    var x = event.offsetX - 10;
    var y = event.offsetY - 10;
    $('#login-btn').append('<div class="circle grow" style="left:' + x + 'px;top:' + y + 'px;"></div>')
  })
  $('#login-btn').mouseup(function() {
    $(this).removeClass('hold-mouse');
  })
})	
</script>
  </body>

</html>
