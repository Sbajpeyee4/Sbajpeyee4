<?php
	 if(!defined('BASEPATH'))
        exit('No direct script access allowed');
    class Common_model extends CI_Model {
        public function __construct()
        {
            parent::__construct();
        }    
	
	
	public function login_user($id,$password){
  
    $result = $this->db->where('client_code',$id)
        ->where('password',$password)
        ->get('clients_table');
    if($result->num_rows() == 1)  {
      return $result->row(0)->client_id;
    }else{
      return false;
    }  
   }
		function check_value($where,$tbl)
			{
			    $this->db->where($where);
			    $query = $this->db->get($tbl)->result_array();
	
			    if (count($query) > 0){
			        return $query[0]['user_id'];
			    }
			    else{
			        return false;
		   }
	}	function check_dupli_value($where,$tbl)
			{
			    $this->db->where($where);
			    $query = $this->db->get($tbl)->result_array();
	
			    if (count($query) > 0){
			        return $query[0]['id'];
			    }
			    else{
			        return false;
		   }
	}

 public function get_limit($id){
     
        $query="SELECT user.current_limit -  IF(SUM(user_limits.limit) IS NULL ,0,  SUM(user_limits.limit)) AS lmt FROM `user`  JOIN  user_limits on user_limits.manager_id = user.id WHERE user.id='$id'";
        return $limit = $this->db->query($query)->result();
        
        
    }
    
	public function insert ($tbl,$data)
			{
					$res = $this->db->insert($tbl,$data);

				return ($res)? $this->db->insert_id() : false;

			}

		public function get_data ($tbl,$data)
			{
					$res = $this->db->where($data)->get($tbl)->result();

				return $res;

			}
		public function get_select_data ($selct, $tbl,$data)
			{
					$res = $this->db->select($selct)->where($data)->get($tbl)->result();

				return $res;

			}
		public function delete_data($tbl,$wh)
			 {

			    $this->db->where($wh);
			    $del=$this->db->delete($tbl);   
			    return $del;

			}
		

	
/*=============================*/
	public function update_data($tbl,$wh,$tag)
	{
	   return  $res = $this->db->where($wh)->update($tbl, $tag);

	}

   
public function export_csv($m_id ,$date)
	{
		 /*$q2 = "SELECT b.user_name ,c.meeting_name,a.time,a.date FROM chat_message as a join user_tbl as b on b.user_id = a.user_id  join meeting_tbl as c on c.m_random_id = a.m_random_id  WHERE c.meet_id  = '$m_id' and a.date = '$date'";*/
		
		$this->db->select("b.user_name ,c.meeting_name,a.massege,a.time,a.date")
			->from('chat_message as a')
			->join('meeting_tbl as c','c.m_random_id = a.m_random_id','INNER')
			->join('user_tbl as b','b.user_id = a.user_id','INNER')
			->where('c.meet_id',$m_id)
			->where('a.date',$date);
				
		return 	$data1 = $this->db->get()->result_array();
				// print_r($data1); die();
		}
	
	public function count_row($tbl,$whr)
	{
		$res = $this->db->where($whr)->count_all_results($tbl);		
		return $res;
		}

	function tag_val($tag_name,$tag_val,$serch,$tbl)
	    {
	        $res = $this->db->select($serch)->where($tag_name,$tag_val)->get($tbl)->result();
	        
	        return $res[0]->$serch;
	    }
         function meail_send($to_email,$from_email,$id)
        	 {
        	        $wh = ['meet_id'=>$id ];
						$data = $this->get_data('meeting_tbl',$wh);

							$type = (count($data))? $data[0]->m_type:'';
							$pass = (count($data))? $data[0]->pass:'';
							$host = (count($data))? $data[0]->host_id:'';
							$meet_name = (count($data))? $data[0]->meeting_name :'';
						
							$date = (count($data))? $data[0]->date:'';
							$from_time = (count($data))? $data[0]->from_time:'';
                          
                            /*==========cheng date and time formet ===================*/
                                 $date_4 = $from_time . ',' . $date;
						 	 	   	              
                                 $new_time =  date('h:i a', strtotime($date_4));
                                       $yrdata= strtotime($date);
                                     $new_date =  date('d-M-Y', $yrdata);
                             /*==========cheng date and time formet end===================*/
                                
						        $aa ="";
							
                                        $ww = ['user_id'=>$host];
                                        $re = $this->get_data('user_tbl',$ww);
                                        $m_random_id = (count($re))? $re[0]->m_random_id : "" ;
                                        
                                        $host_name = (count($re))? $re[0]->user_name : "" ;    
                                        
                        	if($type == 2)
                                     {     
                                        $aa =  base64_encode('public,'.$m_random_id.','.$pass);
                                        }else{
                                                 $aa =  base64_encode('private,'.$id.','.$pass);
                                           }
                             $url = "https://ailive.in/meet/HomeController/index/?meet_id=".$aa;              
                                           
                          //   echo  $host_name. "  ==$host = jk=".$id."==  " .$meet_name; die();
                               
                                                  
                     $srk = "
                            <div style ='background-color:silver; border-radius: 15px;padding: 10px;' >
                                
                        <p style ='background-color:silver;padding: 10px;'>Thank you for using AILive.  The best in Industry Video Conferencing Platform.  Below are your meeting details:</p>
                            <br>
                            <br>
                            <table style ='background-color:silver;padding: 10px;'>
                              <tr>   
                                <th style = 'width: 40%' ></th>
                                <th style = 'width: 50%;  margin-left: 10px;' ></th>
                                
                               
                               <tr>   
                                <td >Host Name:</td>
                                <td >".$host_name."</td>   
                                </tr> 
                                <tr>
                                <td >Meeting Name:</td>
                                <td >".$meet_name."</td>
                                </tr>
                                <tr>
                                <td >Date:</td>
                                <td >".$new_date."</td>
                                </tr>
                                <tr>
                                <td >Time:</td>
                                <td >".$new_time."</td>
                                </tr>
                                <tr>
                                <td >Meeting URL:</td>
                                <td >".$url."</td>
                              </tr>
                              
                            </table>
                            <br>
                            <br>
                             <p style ='background-color:silver;padding: 10px;'>Disclaimer:  Please do not respond to
                                    this email.  This email address is not monitored for responses.  You may contact us at contactus@ailive.in
                                    in case you have questions or queries.</p>
                            <br>
                            <br>
                            <p style ='background-color:silver;padding: 10px;'>Thanks & Regards,
                               <br> Team AILive </p>
                               </div>
                            ";   
                              
                    $from_email = 'info@ailive.in';
        	         $to =  $to_email;
                    $subject = "Join this Url";
                    $txt = $srk;
                   
                    $header = 'From: <info@ailive.in>' . "\r\n";
                     $header .= 'Content-type:text/html;charset=UTF-8' . "\r\n";
                           
                   
                   
                    
                    if(mail($to,$subject,$txt,$header))
                    {   
                        return true;
                        
                    }else{
                            return false;
                             }
        	 }
	function send_url($url)
	   {     
	        $curl_handle=curl_init();
              curl_setopt($curl_handle,CURLOPT_URL,$url);
              curl_setopt($curl_handle,CURLOPT_CONNECTTIMEOUT,2);
              curl_setopt($curl_handle,CURLOPT_RETURNTRANSFER,1);
              $buffer = curl_exec($curl_handle);
              curl_close($curl_handle);
              if (empty($buffer))
              {
                  return false;
                }
                 else{
	                    return true;
                 }
	   }
   
function random_strings($length_of_string)
{ 
    $str_result = '123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefgh'; 
  
    return substr(str_shuffle($str_result),  
                       0, $length_of_string); 
} 

     
     
/*===========================this function use for two time ================================= */

   public function getTimeDiff($dtime,$atime)
    {
        $nextDay = $dtime>$atime?1:0;   
        $dep = explode(':',$dtime);
        $arr = explode(':',$atime);
        $diff = abs(mktime($dep[0],$dep[1],0,date('n'),date('j'),date('y'))-mktime($arr[0],$arr[1],0,date('n'),date('j')+$nextDay,date('y')));
        $hours = floor($diff/(60*60));
        $mins = floor(($diff-($hours*60*60))/(60));
        $secs = floor(($diff-(($hours*60*60)+($mins*60))));
        if(strlen($hours)<2){$hours="0".$hours;}
        if(strlen($mins)<2){$mins="0".$mins;}
        if(strlen($secs)<2){$secs="0".$secs;}
        return $hours.':'.$mins;
    }


    /* ================== chack date function ======================*/  
        // chack date is upcoming and pass for givan date
      
       public function chack_date($dtime,$atime)
       {
              $date = strtotime($my_date);
               
                $tt =   date('d-F-Y', $date);
              
               
                              if(strtotime($tt) > time()) {
                                return "Future Date!";
                              } if(strtotime($tt) < time()) {
                                return "Past Date!";
                              } if(strtotime($tt) == time()) {
                                return "Current Date!";
                              }
       }
     public function user_suggesion($table,$like){
      
		$this->db->select('id,user_name,ldap_id');
		$this->db->from($table);
		$this->db->where($like);
// 		$this->db->like($like);
		$query=$this->db->get();
		return $query->result();
	  } 
	  public function date_validate($date){
      $strdate = $date ;

//Check the length of the entered Date value
if((strlen($strdate)<8)OR(strlen($strdate)>10)){
return "Enter the date in 'dd/mm/yyyy' format";
}
else{
//The entered value is checked for proper Date format
if((substr_count($strdate,"/"))<>2){
return "Enter the date in 'dd/mm/yyyy' format";
}
else{
$pos=strpos($strdate,"/");
$date=substr($strdate,0,($pos));
// print_r($pos);
// print_r($date);
// die();
if(($date<=0)OR($date>31)){
    return "Enter a Valid Date";
}
$month=substr($strdate,($pos+1),($pos));
if(($month<=0)OR($month>12)){
    return "Enter a Valid Month";
}
$year=substr($strdate,($pos+4),strlen($strdate));
$result=preg_match("^[0-9]+$",$year,$trashed);
if(($year<2000)OR($year>2200)){
    return "Enter a year between 1900-2200";
}else {return true;}
}
}
}


	


	

  
  
    


}








