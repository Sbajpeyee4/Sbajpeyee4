<?php

    error_reporting(0);
class Login extends CI_controller{
    public function __construct(){
        parent::__construct();
        
        $this->load->model('Common_model', 'cm');    
       
    }

 public function index(){
     
      $this->load->view('login');
 }
 
 public function log(){
  
	   $id = $this->input->post('id');
	   $password = $this->input->post('password');
	   $user_id = $this->cm->login_user($id,$password);
// 	   echo '<pre>';
// print_r($user_id);
// echo '<pre>';
// die();
			if($user_id>0)
			{
		$id=$this->input->post('id');
        $password=$this->input->post('password');
        // $result=$this->Login_model->logindata($id,$password);
          $result = $this->cm->get_data('clients_table',['client_code'=>$id, 'password'=>$password]);
             date_default_timezone_set("Asia/Kolkata");
            $date =   date("Y-m-d");
            $time = date("H:i:s");
		   if($result>0){
			     $u_id =  $result[0]->client_id;
        	$data=array(
              'client_code'=>$result[0]->client_code,
              'client_id'=>$result[0]->client_id,
              );
          $this->session->set_userdata('client_id', $data);
          
		  $this->session->set_userdata('client_code', $data);
		 
 $client_id= $this->session->userdata['client_id']['client_id'];
 $client_code= $this->session->userdata['client_code']['client_code'];
//  $user_type= $this->session->userdata['user_type']['user_type'];
//main school admin
// echo '<pre>';
// print_r($_SESSION);
// echo '<pre>';
// die();
if($client_id!='')
{ redirect('home/index'); }
 else {
$this->session->set_flashdata('error_msg','Invalid User');
  redirect('login');
}
 /*?><script>
  window.location.assign("<?php echo base_URL(); ?>home");</script><?php*/
      
    }

			}
else{
    $this->session->set_flashdata('error_msg','User Not Found');
             redirect('Login/index');
    }
			}

public function logout() {
	  $this->session->unset_userdata('user_id');
	  $this->session->unset_userdata('user_type');
	 $this->session->sess_destroy();
      redirect ('login');
      }

}