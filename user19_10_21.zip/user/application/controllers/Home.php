<?php

    error_reporting(0);
class Home extends CI_controller{
    public function __construct(){
        parent::__construct();
         $client_id= $this->session->userdata['client_id']['client_id'];
 $client_code= $this->session->userdata['client_code']['client_code'];
   if(empty($client_code)|| empty($client_id) ){ 
     	        ?>
         <script> alert('Please login to your account');window.location.assign("<?php echo base_url(); ?>Login");</script><?php }  

        $this->load->model('Common_model', 'cm');    
        // $this->load->model('Manager_model', 'mm');    
    //     $user_id = $this->session->userdata['user_id']['user_id'];
    //   	$user_role = $this->session->userdata['user_type']['user_type'];
     
    }
 public function index(){
       $client_id = $this->session->userdata['client_id']['client_id'];
      $data['cliend_details'] = $this->cm->get_data('clients_table',['client_id'=>$client_id]);
    //   echo '<pre>';
    //   print_r($client_details);
    //   echo '<pre>';
    //   die();
      $this->load->view('index',$data);
 }
 public function add_bat(){
    //  echo '<pre>';
    //  print_r($_GET);
    //  echo '<pre>';
    //  die();
    
    // $bet_type    = $_GET['bet_type'];
    // $second_team = $_GET['second_team'];
    // $first_team  = $_GET['first_team'];
    // $amount      = $_GET['amount'];
    // $fav_team    = $_GET['fav_team'];
    // $rate        = $_GET['rate'];
    // $match_id    = $_GET['match_id'];
    // $mode        = $_GET['mode'];
     
     $bet_type = $_REQUEST['bet_type'];
     $second_team = $_REQUEST['second_team'];
     $first_team = $_REQUEST['first_team'];
     $amount = $_REQUEST['amount'];
     $fav_team = $_REQUEST['fav_team'];
     $rate = $_REQUEST['rate'];
     $match_id = $_REQUEST['match_id'];
     $mode = $_REQUEST['mode'];
     
     $client_code = $this->session->userdata['client_code']['client_code'];
     $client_id = $this->session->userdata['client_id']['client_id'];
     $client_details = $this->cm->get_data('clients_table',['client_id'=>$client_id]);
     $limit = $client_details[0]->current_limit;
   
       
                 if($mode == 'khai'){
                     $amountsec = ($amount*$rate);
                       $amnt = $amountsec;
                       $winmnt = $amount;
                     if($first_team == $fav_team) $ref_teaam = $second_team; else $ref_teaam = $first_team ;
                     $where = " ( (`bet_type` = '$mode' AND `fav_team` = '$ref_teaam' ) or (`bet_type` = 'lagai' AND `fav_team` = '$fav_team' ) ) AND(  `client_id` = '$client_code' AND `match_id` = '$match_id')";
                    //   $bet_details = $this->cm->get_data('betting_table1',['bet_type' =>$mode ,'fav_team' =>$ref_teaam ,'client_id' =>$client_code, 'match_id' =>$match_id]);
                       $bet_details = $this->cm->get_data('betting_table',$where);
  
                 }else{
                      if($first_team == $fav_team) $ref_teaam = $second_team; else $ref_teaam = $first_team ;
                    $where = " ( (`bet_type` = '$mode' AND `fav_team` = '$ref_teaam' ) or (`bet_type` = 'khai' AND `fav_team` = '$fav_team' ) ) AND(  `client_id` = '$client_code' AND `match_id` = '$match_id')";
                    $bet_details = $this->cm->get_data('betting_table',$where);
                    // $bet_details = $this->cm->get_data('betting_table',['bet_type' =>$mode ,'fav_team' =>$ref_teaam ,'client_id' =>$client_code, 'match_id' =>$match_id]);
                     $amountsec = $amount;
                     $amnt = $amountsec;
                     $winmnt = $amountsec;
                 }
                 foreach($bet_details as $bet_detail){
        //  $amt = $amt + (($bet_detail->amount * $bet_detail->rate) - $bet_detail->refund_amount  );
                    if($bet_detail->bet_type=='khai'){
                     $amt = $amt + (($bet_detail->amount / $bet_detail->rate) - $bet_detail->refund_amount - $bet_detail->initiated_return );
                    }else{
                     $amt = $amt + (($bet_detail->amount * $bet_detail->rate) - $bet_detail->refund_amount - $bet_detail->initiated_return );
                    }
               }
                // echo $amt ; 
                //  die;
                 if($amt!=0){
                    for ($x = 0; $x < count($bet_details); ) {
                        // echo $bet_details[$x]->rate ; 
                        // print_r($bet_details[$x]);
                        // die();
                        // $refund = (($bet_details[$x]->amount * $bet_details[$x]->rate) - $bet_details[$x]->refund_amount);
                        if($bet_details[$x]->bet_type=='khai'){
                        $refund = (($bet_details[$x]->amount / $bet_details[$x]->rate) - $bet_details[$x]->refund_amount -  $bet_detail->initiated_return);
                        }else{
                        $refund = (($bet_details[$x]->amount * $bet_details[$x]->rate) - $bet_details[$x]->refund_amount -  $bet_detail->initiated_return);
                        }
                     if($amountsec<=$refund){
                       
                            $res = $this->cm->update_data('betting_table',['bet_id'=>$bet_details[$x]->bet_id],[ 'refund_amount' =>$bet_details[$x]->refund_amount+$amountsec]);
                            $res = $this->cm->update_data('clients_table',['client_id'=>$client_id],[ 'current_limit' =>$limit+$winmnt]);
                            $retrning_amount = $amountsec ;  
                               $amount = 0; 
                        break;
                     }else{
                         $amountsec = $amountsec - $refund;
                        $retrning_amount = $refund ;
                            $res = $this->cm->update_data('betting_table',['bet_id'=>$bet_details[$x]->bet_id],[ 'refund_amount' =>$bet_details[$x]->refund_amount+$refund]);
                            $x++;
                        }
                    }
                      if($amount > 0 &&  $limit>=$amount){
                            $res = $this->cm->update_data('clients_table',['client_id'=>$client_id],[ 'current_limit' =>$limit-$amountsec]);
                      }
                             $trandata = array(
                                     'amount' =>$amnt,
                                     'user_id' =>$client_id ,
                                     'created_at' =>date('y-m-d') ,
                                    );
                         $result = $this->cm-> insert('bet_transection',$trandata);
                      if($result){
                            $data = array(
                                     'match_id' =>$match_id,
                                     'team_two' =>$second_team ,
                                     'team_one' =>$first_team ,
                                     'amount' =>$amnt ,
                                     'fav_team' =>$fav_team,
                                     'rate' =>$rate ,
                                     'bet_type' =>$mode ,
                                     'status' =>'1', 
                                     'client_id' =>$client_code
                                );
                      $res = $this->cm-> insert('betting_table',$data);
                    }
                          
      }else{ 
                $res = $this->cm->update_data('clients_table',['client_id'=>$client_id],[ 'current_limit' =>$limit-$amountsec]);
                 if($res){
                      $trandata = array(
                             'amount' =>$amountsec,
                             'user_id' =>$client_id ,
                             'created_at' =>date('y-m-d') ,
                             );
                      $resul = $this->cm-> insert('bet_transection',$trandata);
                      if($resul){
                          $data = array(
                                     'match_id' =>$match_id,
                                     'team_two' =>$second_team ,
                                     'team_one' =>$first_team ,
                                     'amount' =>$amountsec ,
                                     'fav_team' =>$fav_team,
                                     'rate' =>$rate ,
                                     'bet_type' =>$mode ,
                                     'status' =>'1', 
                                     'client_id' =>$client_code
                                );
         $res = $this->cm-> insert('betting_table',$data);
     
                      }
                     } 
      }
                     
                     
          
    
      }
      public function add_sess_bat(){
    //  echo '<pre>';
    //  print_r($_REQUEST);
    //  echo '<pre>';
    //  die();
    
    //  $bet_type = $_GET['bet_type'];
    //  $session_name = $_GET['session_name'];
    //  $session_id = $_GET['session_id'];
    //  $amount = $_GET['amount'];
    //  $rate = $_GET['rate'];
    //  $run = $_GET['run'];
    //  $mode = $_GET['mode'];
    //  $match_id = $_GET['match_id'];


     $bet_type = $_REQUEST['bet_type'];
     $session_name = $_REQUEST['session_name'];
     $session_id = $_REQUEST['session_id'];
     $amount = $_REQUEST['amount'];
     $rate = $_REQUEST['rate'];
     $run = $_REQUEST['run'];
     $mode = $_REQUEST['mode'];
     $match_id = $_REQUEST['match_id'];
     
     $match = $this->cm->get_data('session_rate_table',['match_id'=>$match_id,'session_id'=>$session_id]);
     
     if(count($match)>0){
         $session_id = $match[0]->rate_id;
     }else{
          $sessndata = array(
                         'session_id' =>$session_id,
                         'rate' =>$rate ,
                         'session_name' =>$session_name,
                         'match_id' =>$match_id,
                         );
                      $resul = $this->cm-> insert('session_rate_table',$sessndata);
                      $session_id = $resul;
     }
     $client_code= $this->session->userdata['client_code']['client_code'];
     $client_id= $this->session->userdata['client_id']['client_id'];
      $client_details = $this->cm->get_data('clients_table',['client_id'=>$client_id]);
       $limit = $client_details[0]->current_limit ;
    //  print_r($bet_details);
    //  die();
      if($mode=='yes'){
        $pr_mode = 'no';
         $amnt = $amount ; 
         $fanount = $amnt   ; 
         $TESTnt = $amount * $rate ; 
         
       $bet_details = $this->cm->get_data('session_bet',['bet_type' =>$pr_mode ,'session_id' =>$session_id ,'client_id' =>$client_code, 'match_id' =>$match_id ,'run >=' => $run ]);
       
      }else{
        $pr_mode = 'yes';
         $amnt = $amount * $rate ; 
          $TESTnt = $amount * $rate ; 
         $amount = $amnt ;  
         $fanount = $amnt   ; 
       $bet_details = $this->cm->get_data('session_bet',['bet_type' =>$pr_mode ,'session_id' =>$session_id ,'client_id' =>$client_code, 'match_id' =>$match_id ,'run <=' =>$run ]);
      }
      $amt = 0;
    //   echo '<pre>';
    //     print_r($bet_details);
    //   echo '</pre>';
        
      foreach($bet_details as $bet_detail){
        //  $amt = $amt + (($bet_detail->amount * $bet_detail->rate) - $bet_detail->refund_amount  );
        if($bet_detail->bet_type=='no'){
         $amt = $amt + (($bet_detail->amount / $bet_detail->rate) - $bet_detail->refund_amount - $bet_detail->initiated_return );
        }else{
         $amt = $amt + (($bet_detail->amount * $bet_detail->rate) - $bet_detail->refund_amount - $bet_detail->initiated_return );
        }
      }
      
    //   echo $amt; 
    //   echo 'shubh';
    //   die();
      
      if($amt!=0){
        for ($x = 0; $x < count($bet_details); $x++ ) {
            // echo ($bet_details[$x]->amount / $bet_details[$x]->rate) - $bet_details[$x]->refund_amount -$bet_details[$x]->initiated_return ; 
            // print_r($bet_details[$x]);
            // die();
            // echo $bet_details[$x]->bet_type ; 
            // $refund = (($bet_details[$x]->amount * $bet_details[$x]->rate) - $bet_details[$x]->refund_amount);
             if($bet_details[$x]->bet_type =='no'){
                  $refund = (($bet_details[$x]->amount / $bet_details[$x]->rate) - $bet_details[$x]->refund_amount -  $bet_details[$x]->initiated_return);
             }else{
                  $refund = (($bet_details[$x]->amount * $bet_details[$x]->rate) - $bet_details[$x]->refund_amount -  $bet_details[$x]->initiated_return);
             }
            //   echo $TESTnt;
            //   print_r($refund); 
    //   echo 'shubh';
    //   die();
      
         if($TESTnt<=$refund){
           
                $res = $this->cm->update_data('session_bet',['sbet_id'=>$bet_details[$x]->sbet_id],[ 'refund_amount' =>$bet_details[$x]->refund_amount+$TESTnt]);
                $res = $this->cm->update_data('clients_table',['client_id'=>$client_id],[ 'current_limit' =>$limit+$TESTnt]);
                $retrning_amount = $TESTnt ;  
                   $amount = 0; 
            break;
         }else{
            //  echo 'pass';
             $amnt = $amnt - $refund;
              $TESTnt = $TESTnt - $refund;
        //   echo '<br>';
            $retrning_amount =  $retrning_amount + $refund ;
                $res = $this->cm->update_data('session_bet',['sbet_id'=>$bet_details[$x]->sbet_id],[ 'refund_amount' =>round($bet_details[$x]->refund_amount+$refund)]);
                // $x++;
            }
        }
        //   echo $TESTnt;
    //         //   print_r($refund); 
    //   echo 'shubh';
    //   die();
         $amount;
          if($amount > 0 &&  $limit>=$amount){
                $amountsec = $amount;
                // $res = $this->cm->update_data('clients_table',['client_id'=>$client_id],[ 'current_limit' =>$limit-$amountsec]);
                $res = $this->cm->update_data('clients_table',['client_id'=>$client_id],[ 'current_limit' =>$limit-$amnt]);
          $trandata = array(
                         'amount' =>$amnt,
                         'user_id' =>$client_id ,
                         'created_at' =>date('y-m-d') ,
                        );
        $result = $this->cm-> insert('bet_transection',$trandata);
          if($result){
                $data = array(
                             'match_id' =>$match_id,
                             'session_id' =>$session_id ,
                             'run' =>$run ,
                             'amount' =>$fanount ,
                             'rate' =>$rate ,
                             'bet_type' =>$mode ,
                             'initiated_return' => round($retrning_amount) ,
                             'status' =>'1', 
                             'bet_status' =>'0', 
                             'match_status' =>'0', 
                             'client_id' =>$client_code
                        );
        print_r($data);
         $res = $this->cm-> insert('session_bet',$data);
                }
          }else{
               $trandata = array(
                         'amount' =>$amnt,
                         'user_id' =>$client_id ,
                         'created_at' =>date('y-m-d') ,
                        );
        $result = $this->cm-> insert('bet_transection',$trandata);
          if($result){
                $data = array(
                             'match_id' =>$match_id,
                             'session_id' =>$session_id ,
                             'run' =>$run ,
                             'amount' =>$fanount ,
                             'rate' =>$rate ,
                             'bet_type' =>$mode ,
                             'initiated_return' =>$retrning_amount ,
                             'status' =>'1', 
                             'bet_status' =>'0', 
                             'match_status' =>'0', 
                             'client_id' =>$client_code
                        );
        print_r($data);
         $res = $this->cm-> insert('session_bet',$data);
                }
          }
      }else{
        //   $limit = $client_details[0]->current_limit + $amt;

           if($limit>=$amount){
                     $amountsec = $amount;
                    $res = $this->cm->update_data('clients_table',['client_id'=>$client_id],[ 'current_limit' =>$limit-$amountsec]);
                     if($res){
                           $trandata = array(
                                 'amount' =>$amountsec,
                                 'user_id' =>$client_id ,
                                 'created_at' =>date('y-m-d') ,
                                 );
                      $result = $this->cm-> insert('bet_transection',$trandata);
                      if($result){
                           $data = array(
                                     'match_id' =>$match_id,
                                     'session_id' =>$session_id ,
                                     'run' =>$run ,
                                     'amount' =>$amountsec ,
                                     'rate' =>$rate ,
                                     'bet_type' =>$mode ,
                                     'status' =>'1', 
                                     'bet_status' =>'0', 
                                     'match_status' =>'0', 
                                     'client_id' =>$client_code
                                );
                                print_r($data);
         $res = $this->cm-> insert('session_bet',$data);
         
     
                      }
                     } 
                     
                     
           }
      }
    
      }
 public function test(){
     
      $this->load->view('test');
 }
 public function casino(){
      $client_id = $this->session->userdata['client_id']['client_id'];
      $data['cliend_details'] = $this->cm->get_data('clients_table',['client_id'=>$client_id]);
      $this->load->view('casino',$data);
 }
 public function changepass(){
     
      $this->load->view('changepass');
 }
 public function completegame(){
      $client_id = $this->session->userdata['client_id']['client_id'];
      $data['cliend_details'] = $this->cm->get_data('clients_table',['client_id'=>$client_id]);
    //  print_r($data);
    //       die();
      $this->load->view('completegame',$data);
 }
 public function crickerdetail(){
     $id = $this->uri->segment(3);
 $client_id= $this->session->userdata['client_id']['client_id'];
 $client_code= $this->session->userdata['client_code']['client_code'];
           $match = $this->cm->get_data('match_table',['match_id'=>$id]);
          $data['match_data'] = $match;
          $data['user_data'] = $this->cm->get_data('clients_table',['client_id'=>$client_id]); 
          $data['bat_data'] = $this->cm->get_data('betting_table',['client_id'=>$client_code,'match_id'=>$match[0]->match_code]); 
        //   print_r($data);
        //   die();
      $this->load->view('crickerdetail',$data);
 }
 public function cricket_details(){
     $id = $this->uri->segment(3);
 $client_id= $this->session->userdata['client_id']['client_id'];
 $client_code= $this->session->userdata['client_code']['client_code'];
           $match = $this->cm->get_data('match_table',['match_id'=>$id]);
           $data['used_coin'] = $this->db->query("SELECT SUM(amount) as used FROM `bet_transection` WHERE `user_id`='$client_id'")->result_array(); 
        //   print_r($data);
        //   die();
          $data['match_data'] = $match;
          $data['user_data'] = $this->cm->get_data('clients_table',['client_id'=>$client_id]); 
          $data['bat_data'] = $this->cm->get_data('betting_table',['client_id'=>$client_code,'match_id'=>$match[0]->match_code]); 
          $data['sess_bat_data'] = $this->cm->get_data('session_bet',['client_id'=>$client_code,'match_id'=>$match[0]->match_code]); 
        
      $this->load->view('cricket_details',$data);
 }
 
 public function testapi(){
      $code = $this->uri->segment(3);
    //   $testurl="http://marketsarket.in:3000/getcricketdemo/".$code;
       $testurl="http://13.232.88.173/getdata/".$code;
        $curl = curl_init();

// set our url with curl_setopt()
curl_setopt($curl, CURLOPT_URL, $testurl);

// return the transfer as a string, also with setopt()
curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);

// curl_exec() executes the started curl session
// $output contains the output string
$output = curl_exec($curl);

// close curl resource to free up system resources
// (deletes the variable made by curl_init)
curl_close($curl);
 echo $output;
  
     
 } 
 
 public function inplay(){
         $client_id = $this->session->userdata['client_id']['client_id'];
      $data['cliend_details'] = $this->cm->get_data('clients_table',['client_id'=>$client_id]);
     $data['matches'] = $this->cm->get_data('match_table',['status'=>1]);
    //  echo '<pre>';
    //  print_r($data);
    //  echo '<pre>';
    //  die();
      $this->load->view('inplay',$data);
 } 
 public function ledger(){
       $client_id = $this->session->userdata['client_id']['client_id'];
      $data['cliend_details'] = $this->cm->get_data('clients_table',['client_id'=>$client_id]);
      $this->load->view('ledger',$data);
 }
 public function profile(){
       $client_id = $this->session->userdata['client_id']['client_id'];
      $data['cliend_details'] = $this->cm->get_data('clients_table',['client_id'=>$client_id]);
      $this->load->view('profile',$data);
 }
  public function result(){
     
      $this->load->view('result');
 }
 public function terms(){
     
      $this->load->view('terms');
 }
 public function mytest(){
     
      $this->load->view('mytest');
 }
 
 
}